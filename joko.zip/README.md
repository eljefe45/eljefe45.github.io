# joko

OPSEC plugin by El Jefe.

## Load in Revenge (Official Method) [citation:1]
1. Settings > General > Enable Developer Settings
2. Settings > Developer > Enable "Load from custom URL"
3. Enter: https://eljefe.edgeone.dev/revenge.js
4. Restart Discord

## Commands
- +wipe - Delete your messages
- +collect <userid> - Fetch user data
- +ai <message> - AI response
